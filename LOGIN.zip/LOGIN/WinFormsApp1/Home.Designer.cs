﻿namespace KVG_APPLICATION
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            panel1 = new Panel();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            panel3 = new Panel();
            panel2 = new Panel();
            label1 = new Label();
            firstCustomControl1 = new WinFormsApp1.FirstCustomControl();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Controls.Add(button5);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(panel3);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(155, 640);
            panel1.TabIndex = 0;
            // 
            // button5
            // 
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("MS UI Gothic", 14F, FontStyle.Bold);
            button5.ForeColor = Color.White;
            button5.Location = new Point(12, 390);
            button5.Name = "button5";
            button5.Size = new Size(127, 43);
            button5.TabIndex = 3;
            button5.Text = "About Us";
            button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("MS UI Gothic", 14F, FontStyle.Bold);
            button4.ForeColor = Color.White;
            button4.Location = new Point(12, 326);
            button4.Name = "button4";
            button4.Size = new Size(127, 43);
            button4.TabIndex = 3;
            button4.Text = "Purchases";
            button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("MS UI Gothic", 14F, FontStyle.Bold);
            button3.ForeColor = Color.White;
            button3.Location = new Point(12, 256);
            button3.Name = "button3";
            button3.Size = new Size(127, 43);
            button3.TabIndex = 3;
            button3.Text = "For Women";
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("MS UI Gothic", 14F, FontStyle.Bold);
            button2.ForeColor = Color.White;
            button2.Location = new Point(12, 190);
            button2.Name = "button2";
            button2.Size = new Size(127, 43);
            button2.TabIndex = 3;
            button2.Text = "For Men";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("MS UI Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(12, 128);
            button1.Name = "button1";
            button1.Size = new Size(127, 43);
            button1.TabIndex = 3;
            button1.Text = "Home";
            button1.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            panel3.Location = new Point(154, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(198, 196);
            panel3.TabIndex = 2;
            // 
            // panel2
            // 
            panel2.BackColor = Color.SaddleBrown;
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(155, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1118, 63);
            panel2.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("MS UI Gothic", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Transparent;
            label1.Location = new Point(458, 18);
            label1.Name = "label1";
            label1.Size = new Size(187, 27);
            label1.TabIndex = 0;
            label1.Text = "KAVOGUE.mnl";
            // 
            // firstCustomControl1
            // 
            firstCustomControl1.Location = new Point(154, 51);
            firstCustomControl1.Name = "firstCustomControl1";
            firstCustomControl1.Size = new Size(1119, 589);
            firstCustomControl1.TabIndex = 2;
            // 
            // Home
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1273, 640);
            Controls.Add(firstCustomControl1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "Home";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Home";
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Label label1;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private WinFormsApp1.FirstCustomControl firstCustomControl1;
    }
}