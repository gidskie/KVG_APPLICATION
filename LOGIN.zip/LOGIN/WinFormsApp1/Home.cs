﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KVG_APPLICATION
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void btnEros_Click(object sender, EventArgs e)
        {
            // Assuming you have a method to calculate the payment amount
            decimal paymentAmount = CalculatePaymentAmount();

            // Replace these URLs with your actual return and cancel URLs
            string returnUrl = "https://kavogue.my.canva.site/success";
            string cancelUrl = "https://kavogue.my.canva.site/failed";

            string paypalUrl = $"https://www.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token=A21AAKBFDnnp-sfYm-gU8ccCUZ4i4CINxPTQF4pYAhC5OPrE46Czh0oDh-IHY63XlThkiQoK8t8Lo2juKapFIu9KbkdpdLNEw&useraction=commit&return={returnUrl}&cancel_return={cancelUrl}";

            WebBrowserForm webBrowserForm = new WebBrowserForm(paypalUrl);
            webBrowserForm.ShowDialog();


        }

        private decimal CalculatePaymentAmount()
        {

            return 220.00M;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }

    public class WebBrowserForm : Form
    {
        private readonly WebBrowser webBrowser;

        public WebBrowserForm(string url)
        {
            webBrowser = new WebBrowser();
            webBrowser.Navigate(url);
            webBrowser.Dock = DockStyle.Fill;

            Controls.Add(webBrowser);
        }
    }
}